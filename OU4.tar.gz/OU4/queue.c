/* */
# include "queue.h"
#include <stdio.h>

/*  */
queue* q_create(){
	queue* q = list_create();
	return q;
}

/* */
void q_dequeue(queue* q){
    node* p = list_first(q);
	node* t = list_remove(q, p);
	printf("POP\n");
}


/* */
void q_enqueue(queue* q, void* element){
	list_insert(q, list_first(q), element);
}


/* */
bool q_isEmpty(queue* q){
	return list_isEmpty(q);
}


/* */
void* q_peek(queue* q){
	return list_getValue(q, list_first(q));
}


/* */
void q_free(queue* q){
	list_free(q);
}
