#include "checkComLine.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "queue.h"

/* Main */
int main(int argc, char* argv[]){
	
	int mode = checkGivenFlags(argc, argv);
	command* c = getCommand(argc, argv, mode);
	
	printf("t: %c\n", c -> type);
	printf("nrt: %d\n", c -> nrthr);
	printf("start 0: %s \n",c -> start[0]);
	printf("name: %s \n",c -> name);

	queue* q = q_create();

	printf("q is empty: %d\n", q_isEmpty(q));
	char a = 'a',b='b';
	
	void* p = &a;

	printf("Insert a. ");
	q_enqueue(q,p);
	p = &b;
	printf("Insert b.");
	q_enqueue(q,p);
	printf("q(0): %c\n", *(char*)q_peek(q));
	printf("q is empty nn: %d\n", q_isEmpty(q));

	char* m = (char*) q_peek(q);
    

	printf("q(0): %c\n", *m);
	
	q_dequeue(q);

	free(c);
	return 0;
}